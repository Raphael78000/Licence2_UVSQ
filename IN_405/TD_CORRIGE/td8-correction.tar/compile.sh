#!/bin/sh

gcc million.c se_fichier.c -o million
