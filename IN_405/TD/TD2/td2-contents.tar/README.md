L'archive td2-contents.tar contient les fichiers suivants :
- le fichier README.md, que vous êtes en train de lire ;
- le fichier mystery-code.c, que vous allez devoir débugger
  dans l'exercice 2.5 ;
- le fichier example-script.sh, qui vous montre une brève utilisation
  des variables et structures de contrôle en Shell.

La compilation du fichier mystery-code.c se fait sans option particulière,
mise à part celle pour activer les informations de debug.