void tri_base(Tableau t);

void tri_cmp(Tableau t);
