
void  chrono_reset();
double chrono_lap();
